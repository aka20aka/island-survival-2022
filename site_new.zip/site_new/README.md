# Island Survival 2022

This is a Scratch/TurboWarp project.

- Open `index.html` for the main page (play + download).
- Or go to `play.html` for full screen play.

Files included:
- `index.html`
- `play.html`
- `game.sb3`
- `assets/style.css`
